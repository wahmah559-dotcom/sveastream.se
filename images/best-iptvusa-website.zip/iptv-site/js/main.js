// ============================================
// BEST IPTV USA - MAIN JAVASCRIPT
// ============================================

document.addEventListener('DOMContentLoaded', function() {
  
  // ===== Navbar Scroll Effect =====
  const navbar = document.querySelector('.navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    });
  }
  
  // ===== Mobile Menu Toggle =====
  const mobileToggle = document.querySelector('.mobile-toggle');
  const navLinks = document.querySelector('.nav-links');
  
  if (mobileToggle && navLinks) {
    mobileToggle.addEventListener('click', () => {
      navLinks.classList.toggle('open');
      const isOpen = navLinks.classList.contains('open');
      mobileToggle.innerHTML = isOpen ? '✕' : '☰';
    });
    
    // Close on link click
    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('open');
        mobileToggle.innerHTML = '☰';
      });
    });
  }
  
  // ===== FAQ Accordion =====
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    if (question) {
      question.addEventListener('click', () => {
        const isActive = item.classList.contains('active');
        faqItems.forEach(i => i.classList.remove('active'));
        if (!isActive) {
          item.classList.add('active');
        }
      });
    }
  });
  
  // ===== Tutorial Tabs =====
  const tabs = document.querySelectorAll('.tutorial-tab');
  const contents = document.querySelectorAll('.tutorial-content');
  
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const target = tab.dataset.tab;
      
      tabs.forEach(t => t.classList.remove('active'));
      contents.forEach(c => c.classList.remove('active'));
      
      tab.classList.add('active');
      const targetContent = document.getElementById(target);
      if (targetContent) {
        targetContent.classList.add('active');
      }
    });
  });
  
  // ===== Fade-in on Scroll =====
  const fadeElements = document.querySelectorAll('.fade-in');
  
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, { threshold: 0.1 });
  
  fadeElements.forEach(el => observer.observe(el));
  
  // ===== Contact Form =====
  const contactForm = document.querySelector('#contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const name = document.getElementById('name').value;
      const email = document.getElementById('email').value;
      const subject = document.getElementById('subject') ? document.getElementById('subject').value : 'IPTV Inquiry';
      const message = document.getElementById('message').value;
      
      // Build WhatsApp message
      const whatsappMessage = `Hello! My name is ${name}.%0A%0AEmail: ${email}%0ASubject: ${subject}%0A%0AMessage:%0A${message}`;
      const whatsappURL = `https://wa.me/17867352904?text=${encodeURIComponent(whatsappMessage).replace(/%2520/g, '%20')}`;
      
      window.open(whatsappURL, '_blank');
    });
  }
  
  // ===== Smooth scroll for anchor links =====
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const href = this.getAttribute('href');
      if (href === '#' || href.length <= 1) return;
      
      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        const offset = 80;
        const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - offset;
        window.scrollTo({
          top: targetPosition,
          behavior: 'smooth'
        });
      }
    });
  });
  
  // ===== Year in footer =====
  const yearEl = document.getElementById('year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }
});

// ===== WhatsApp helper =====
function sendWhatsApp(plan) {
  const messages = {
    '1': 'Hi! I would like to subscribe to the 1 Month Plan ($14). Please send me payment details.',
    '3': 'Hi! I would like to subscribe to the 3 Months Plan ($29). Please send me payment details.',
    '6': 'Hi! I would like to subscribe to the 6 Months Plan ($39). Please send me payment details.',
    '12': 'Hi! I would like to subscribe to the 12 Months Plan ($59). Please send me payment details.',
    'trial': 'Hi! I would like to request a Free Trial. Please send me the activation details.',
    'general': 'Hi! I am interested in your IPTV service. Can you give me more information?'
  };
  
  const message = messages[plan] || messages['general'];
  const url = `https://wa.me/17867352904?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
  return false;
}
